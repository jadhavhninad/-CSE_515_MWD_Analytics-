##mysql password for user root: surajshah and databasename: mwdb_suraj
sudo apt-get install build-essential libssl-dev libffi-dev
sudo apt-get install libmysqlclient-dev
sudo apt-get install git git-core zsh
sudo apt-get install python-pip
sudo apt-get install gunicorn supervisor nginx
sudo apt-get install mysql-server mysql-client
sudo apt-get build-dep python-psycopg2
sudo apt-get install python-mysqldb
sudo apt-get install python-tk

